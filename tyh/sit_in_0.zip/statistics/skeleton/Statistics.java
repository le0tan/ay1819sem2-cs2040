/**
 * Name         :
 * Matric. No   :
 * PLab Acct.   :
 */

import java.util.*;

public class Statistics {
	private void run() {
		//implement your "main" method here
	}
	
	public static void main(String[] args) {
		Statistics newStatistics = new Statistics();
		newStatistics.run();
	}
}
