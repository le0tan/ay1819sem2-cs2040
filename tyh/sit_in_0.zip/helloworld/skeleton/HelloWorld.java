/**
 * Name         :
 * Matric. No   :
 * PLab Acct.   :
 */

import java.util.*;

public class HelloWorld {
	private void run() {
		//implement your "main" method here
	}

	public static void main(String[] args) {
		HelloWorld newHelloWorld = new HelloWorld();
		newHelloWorld.run();
	}
}
