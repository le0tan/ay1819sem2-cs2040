/**
 * Name         :
 * Matric. No   :
 * PLab Acct.   :
 */

import java.util.*;

public class Transpose {
	private void run() {
		//implement your "main" method here
	}

	public static void main(String[] args) {
		Transpose newTranspose = new Transpose();
		newTranspose.run();
	}
}
