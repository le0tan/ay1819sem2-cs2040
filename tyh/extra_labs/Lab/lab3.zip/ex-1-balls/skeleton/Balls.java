/**
 * name	     :
 * matric no.:
 */
 
import java.util.*;

// use ListNode to represent the balls.
class ListNode {
	
}

class MyLinkedList {
	
    // declare the member field
	
    // declare the constructor
	
	/**
	 *		doA				: implement the operation for A
	 * 		Pre-condition  	:
	 * 		Post-condition 	:
	 */	
	public void doA(int x, int y) {
		// implementation
		return;
	}


	/**
	 *		doB				: implement the operation for B
	 * 		Pre-condition  	:
	 * 		Post-condition 	:
	 */	
	public void doB(int x, int y) {
		// implementation
		return;
	}


	/**
	 *		doR				: implement the operation for R
	 * 		Pre-condition  	:
	 * 		Post-condition 	:
	 */
	public void doR(int x) {
		// implementation
		return;
	}

}

class Balls {
	
	public static void main(String[] args) {
        
		// declare the necessary variables

		// declare a Scanner object to read input

		// read input and process them accordingly
	}
}
