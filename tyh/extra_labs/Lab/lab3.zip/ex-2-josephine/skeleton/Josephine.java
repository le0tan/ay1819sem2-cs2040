/**
 * name	     :
 * matric no.:
 */
 
import java.util.*;

// use ListNode to represent a person in the circle
class ListNode {

}

class Result {
	
    // declare the member field

    // declare the constructor

	/**
	 *		remove			: removing K-th person and update the state
	 * 		Pre-condition  	:
	 * 		Post-condition 	:
	 */
	private void remove(int K) {
		// implementation
		return;
	}

	/**
	 *		solve			: keep removing K-th person from the circle to find the Chosen One
	 * 		Pre-condition  	:
	 * 		Post-condition	:
	 */
	public void solve() {
		// implementation
		return;
	}
}

public class Josephine {
	
	public static void main(String[] args) {
        
		// declare the necessary variables

		// declare a Scanner object to read input

		// read input and process them accordingly
	}
}