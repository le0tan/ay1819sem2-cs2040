/**
 * name	     :
 * matric no.:
 */
 
import java.util.*;

// use ListNode to represent a person in the circle
class ListNode {

}

class Result {
	
    // declare the member field

    // declare the constructor

	/**
	 *		moveLeft		: Press the left key K times
	 * 		Pre-condition  	:
	 * 		Post-condition 	:
	 */
	private void moveLeft(int K) {
		// implementation
		return;
	}

	/**
	 *		moveRight		: Press the right key K times
	 * 		Pre-condition  	:
	 * 		Post-condition	:
	 */
	public void moveRight(int K) {
		// implementation
		return;
	}

	/**
	 *		insertCharacter	: Insert character X at the current position
	 * 		Pre-condition  	:
	 * 		Post-condition	:
	 */
	public void insertCharacter(char X) {
		// implementation
		return;
	}

	/**
	 *		deleteCharacter	: Delete the character at the current position
	 * 		Pre-condition  	:
	 * 		Post-condition	:
	 */
	public void deleteCharacter() {
		// implementation
		return;
	}
}

public class Keyboard {
	
	public static void main(String[] args) {
        
		// declare the necessary variables

		// declare a Scanner object to read input

		// read input and process them accordingly
	}
}
