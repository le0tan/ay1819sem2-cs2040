import java.util.*;

class Matrix {
	int size;
	int matrix[][];
	public Matrix() {}
	public Matrix(int size) {
		this.size = size;
		this.matrix = new int[size][size];
	}
}

class Transformation {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);		
	}
}