/**
 * name	     :
 * matric no.:
 */

import java.util.*;

class Grid {

    // declare the member field

    // declare the constructor

	/**
	 *	   checkNoTree   : to check whether the (size x size) square with upper-left coordinate 
	 *                     (x, y) contains a tree
	 *	   Pre-condition :
	 *	   Post-condition:
	 */
	public boolean checkNoTree(int x, int y, int size) {
		// implementation
    return false;
	}



	/**
	 *	   checkValidSize: to check whether it is possible to find a (size x size) square that contains 
	 *                     no tree
	 *	   Pre-condition :
	 *	   Post-condition:
	 */
	public boolean checkValidSize(int size) {
    return false;
	}



	/** 
	 *	   solve         : use this method to find the largest size of a square with no trees
	 *	   Pre-condition :
	 *	   Post-condition:
	 */
	public int solve() {
    return 0;
	}

}

class Land {

	public static void main(String[] args) {

		// declare the necessary variables

		// create new object from class Result

		// declare a Scanner object to read input

		// read input and process them accordingly
	}
}
