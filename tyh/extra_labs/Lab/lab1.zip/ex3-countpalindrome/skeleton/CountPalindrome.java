import java.util.*;

class CountPalindrome {
  /**
   * Count how many palindrome is inside the matrix.
   */
  public int solve(String[] matrix) {
    return 0;
  }

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);		
	}
}

