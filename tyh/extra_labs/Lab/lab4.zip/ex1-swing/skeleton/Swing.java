/*****************************
 *  Name: 
 *  Matric Number:
******************************/

import java.util.*;

class Swing
{
	public static void main(String [] args)
	{
		Scanner sc = new Scanner (System.in);
	}
}
