import java.util.*;

class Stick
{

	public static void main(String [] args)
	{
		Scanner sc = new Scanner(System.in);

	}
}
