import java.util.*;

class Triplet
{

	public static void main(String [] args)
	{
		Scanner sc = new Scanner(System.in);

	}
}
