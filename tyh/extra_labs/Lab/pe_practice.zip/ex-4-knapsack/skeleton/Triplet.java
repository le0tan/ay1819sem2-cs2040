import java.util.*;

class Knapsack
{

	public static void main(String [] args)
	{
		Scanner sc = new Scanner(System.in);

	}
}
