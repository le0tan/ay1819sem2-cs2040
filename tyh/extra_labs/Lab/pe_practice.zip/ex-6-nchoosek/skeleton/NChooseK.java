import java.util.*;

class NChooseK
{

	public static void main(String [] args)
	{
		Scanner sc = new Scanner(System.in);

	}
}
