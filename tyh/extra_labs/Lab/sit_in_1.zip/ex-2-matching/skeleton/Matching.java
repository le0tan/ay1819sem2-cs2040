/**
 * Name	       :
 * Matric no.  :
 * Plab account:
 */

import java.util.*;

class Matching {

	public static void main(String[] args) {

		// declare the necessary variables

		// declare a Scanner object to read input

		// read input and process them accordingly
	}
}
