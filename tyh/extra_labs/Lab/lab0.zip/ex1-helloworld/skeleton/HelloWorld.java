/**
 *
 * author	: []
 * matric no: []
 * 
 */

import java.util.*;

public class HelloWorld {
	
	public static void main(String[] args) {

		// declare the necessary variables


		// declare a Scanner object to read input


		// read input and process them accordingly

	}
}
