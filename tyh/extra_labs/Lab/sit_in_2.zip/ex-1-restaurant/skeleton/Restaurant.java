/**
 * Name        :
 * Matric no.  :
 * Plab account:
 */

class Group {
	private String name;
	private int size;
}

class Table {
	private String name;
	private int capacity;
	private Group group;
}

public class Restaurant {
	public static void main(String[] args) {
	}
}
