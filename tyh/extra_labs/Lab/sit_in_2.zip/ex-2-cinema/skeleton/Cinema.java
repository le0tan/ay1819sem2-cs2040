/**
 * Name        :
 * Matric no.  :
 * Plab account:
 */

import java.util.*;

class Group {
	String name;
	int count;
}

class Row {
	String name;
	int capacity;
}

public class Cinema {

	public static void main(String[] args) {
	}
}
