class Account {
	// data member goes here
	// account name
		
	// initial balance
		
	// current balance
		
	// constructors, destructors
	
	// setters, getters
}

class Bank {
	public void create(String name, double balance){

	}
	public void deposit(String name, double value){

	}
	public void withdraw(String name, double value){

	}
}

public class Main {

	public static void main(String[] args) {
		// your main program here

	}

}
