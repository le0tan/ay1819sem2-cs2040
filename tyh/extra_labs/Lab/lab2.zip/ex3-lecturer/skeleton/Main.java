import java.util.ArrayList;

class Lecturer {
	private String name;
	private boolean active;

	public Lecturer(){
		
	}
}

class Office {
	private String name;
	private ArrayList<Lecturer> lecturerList;

	public Office(){
		
	}
}

public class Main {

	public static void main(String[] args) {
		// your main program here

	}

}
