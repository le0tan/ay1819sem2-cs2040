import java.util.*;

public class ECP {
    public static void main(String[] args) {
        //define your main method here
    }
}

class Championship {
    //define the appropriate attributes, constructor, and methods here
}

class Team {
    //define the appropriate attributes, constructor, and methods here
}
