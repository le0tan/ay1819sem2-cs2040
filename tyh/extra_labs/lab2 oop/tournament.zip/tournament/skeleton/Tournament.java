/*
Name: 
Matric Number: 
*/

public class Tournament {
	public static void main(String[] args) {
		
	}	
}

class Participant {
    //define the appropriate attributes and constructor
}
