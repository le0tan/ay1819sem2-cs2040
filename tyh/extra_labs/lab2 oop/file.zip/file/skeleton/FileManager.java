/*
Name: 
Matric Number: 
*/

import java.util.*;

public class FileManager {
	public static void main(String[] args) {
		
	}

}

class File {
	//define the appropriate attributes and constructor

}

class Folder {
	//define the appropriate attributes and constructor
}
