/**
 * Name         :
 * Matric No.   :
 * PLab Acct.   :
 */

import java.util.*;

public class ICPC {

    // define your own attributes, constructor, and methods here

    private void run() {

    }

    public static void main(String[] args) {
        ICPC competition = new ICPC();
        competition.run();
    }
}

class Problem {
    // define your own attributes, constructor, and methods here
}

class Team {
    // define your own attributes, constructor, and methods here
}
