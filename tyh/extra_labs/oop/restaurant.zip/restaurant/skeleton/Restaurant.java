/*
Name:
Matric Number:
*/

public class Restaurant {
	public static void main(String[] args) {

	}
}

class Group {
	private String name;
	private int size;

    //define the appropriate constructor and methods
}

class Table {
	private String name;
	private int capacity;
	private Group group;

    //define the appropriate constructor and methods
}
