/*
* Name:
* Matric No. :
*/

import java.util.*;

public class Game {

    public static void main(String[] args) {

    }

}

class Warrior {
    // define appropriate attributes, methods, and constructor here
}

class Weapon {
    // define appropriate attributes, methods, and constructor here
}
