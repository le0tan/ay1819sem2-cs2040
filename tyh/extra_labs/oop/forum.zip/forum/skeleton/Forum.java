import java.util.*;

public class Forum {
	public static void main(String[] args) {
        //define your main method here
	}
}

class Thread {
    //define the appropriate attributes, constructor, and methods here
}

class Post {
    //define the appropriate attributes, constructor, and methods here
}

class User {
    //define the appropriate attributes, constructor, and methods here
}
