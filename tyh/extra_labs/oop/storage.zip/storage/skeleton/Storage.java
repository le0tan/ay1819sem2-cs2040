/**
 * Name         :
 * Matric No.   :
 * Plab Acct.   :
 */

public class Storage {
    
    public void run() {
        // treat this as your "main" method
    }
    
    public static void main(String[] args) {
        Storage myStorageSystem = new Storage();
        myStorageSystem.run();
    }

}

class Box {
    // define appropriate attributes, constructor, and methods
}

class Item {
    // define appropriate attributes, constructor, and methods
}