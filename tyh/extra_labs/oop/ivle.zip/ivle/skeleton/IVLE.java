/**
 * Name         :
 * Matric No.   :
 * PLab Acct.   :
 */

import java.util.*;

public class IVLE {

    // define your own attributes, constructor, and methods here

    private void run() {

    }

    public static void main(String[] args) {
        IVLE ivle = new IVLE();
        ivle.run();
    }
}

class Module {
    // define your own attributes, constructor, and methods here
}

class Student {
    // define your own attributes, constructor, and methods here
}
